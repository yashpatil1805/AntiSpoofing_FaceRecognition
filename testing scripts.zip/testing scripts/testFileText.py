f= open("test.txt",'a')
f.write("This is a new line\n")
f.close()